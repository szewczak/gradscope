#!/usr/bin/env bash

apt-get install -y python3 python-pip python-dev

pip install subprocess32 gradescope-utils 
